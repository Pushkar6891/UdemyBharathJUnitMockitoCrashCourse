package com.bharath.maven.calculator;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorImplTest {

	@Test
	public void testAddShouldReturnAResult() {
		CalculatorImpl calculator = new CalculatorImpl();
		int result = calculator.add(10, 20);
		assertEquals(30, result);
	}

}
