package com.bharath.order.dao;

import java.sql.SQLException;

import com.bharath.order.dto.Order;

public class OrderDaoImpl implements OrderDAO {

	@Override
	public int create(Order order) throws SQLException {
		return 0;
	}

	@Override
	public Order read(int orderId) throws SQLException {
		return null;
	}

	@Override
	public int update(Order order) throws SQLException {
		return 0;
	}

	@Override
	public int delete(int orderId) throws SQLException {
		return 0;
	}

}
