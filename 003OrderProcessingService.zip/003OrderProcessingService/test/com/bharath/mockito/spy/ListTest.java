package com.bharath.mockito.spy;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;

import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

public class ListTest {

	@Spy
	List<String> myList = new LinkedList<>();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void test1() {
		myList.add("Pushkar");
		myList.add("Sachin");

		// Stub Methods on Spy
		Mockito.doReturn(3).when(myList).size();
		assertSame(3, myList.size());
	}
	
	@Test
	public void test2() {
		// Mocking a call on get(0) We cannot use when syntax on a spy
		// spy calls real method InCorrect Way
		Mockito.when(myList.get(0)).thenReturn("Rambo");
		// Stub Methods on Spy Correct Way
		Mockito.doReturn(3).when(myList).size();
		assertSame(3, myList.size());
	}

}

// Spy uses real objects
// Mock : if we mock nothing happens util we stub out a method call

// Do not use Spy use Mock is better
