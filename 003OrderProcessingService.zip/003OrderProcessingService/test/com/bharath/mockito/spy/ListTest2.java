package com.bharath.mockito.spy;

import static org.junit.Assert.assertSame;

import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class ListTest2 {

	@Mock
	List<String> myList = new LinkedList<>();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test2() {
	
		Mockito.when(myList.get(0)).thenReturn("Rambo");
		Mockito.when(myList.size()).thenCallRealMethod();
		assertSame(3, myList.size());
	}

}

