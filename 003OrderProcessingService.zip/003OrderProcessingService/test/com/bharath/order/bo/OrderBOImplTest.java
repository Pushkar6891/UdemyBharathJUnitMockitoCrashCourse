package com.bharath.order.bo;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.bharath.order.bo.exception.BOException;
import com.bharath.order.dao.OrderDAO;
import com.bharath.order.dto.Order;

public class OrderBOImplTest {

	private static final int ORDER_ID = 123;

	@Mock
	OrderDAO dao;
	private OrderBOImpl bo;

	private Order order;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		bo = new OrderBOImpl();
		bo.setDao(dao);
		order = new Order();
	}

	@Test
	public void testPlaceOrder_Should_Create_An_Order_1_positive() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(order)).thenReturn(new Integer(1));
		boolean result = bo.placeOrder(order);
		assertTrue(result);
		verify(dao).create(order);
	}

	@Test
	public void testPlaceOrder_Should_Create_An_Order_2_positive() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(order)).thenReturn(new Integer(1));
		boolean result = bo.placeOrder(order);
		assertTrue(result);
		verify(dao, times(1)).create(order);
		verify(dao, atLeast(1)).create(order);
	}

	@Test
	public void testPlaceOrder_Should_Not_Create_An_Order_negative() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(order)).thenReturn(new Integer(0));
		boolean result = bo.placeOrder(order);
		assertFalse(result);
		verify(dao).create(order);
	}

	@Test(expected = BOException.class)
	public void testPlaceOrder_Should_throwBOException() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(order)).thenThrow(SQLException.class);
		boolean result = bo.placeOrder(order);
	}

	@Test
	public void testCancelOrder_Should_Cancel_the_Order_positive() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenReturn(order);
		when(dao.update(order)).thenReturn(1);
		boolean result = bo.cancelOrder(ORDER_ID);
		assertTrue(result);
		verify(dao).read(ORDER_ID);
		verify(dao).update(order);
	}

	@Test
	public void testCancelOrder_Should_Not_Cancel_the_Order_negative() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenReturn(order);
		when(dao.update(order)).thenReturn(0);
		boolean result = bo.cancelOrder(ORDER_ID);
		assertFalse(result);
		verify(dao).read(ORDER_ID);
		verify(dao).update(order);
	}

	@Test(expected = BOException.class)
	public void testCancelOrder_ShouldThrowBOExceptionOnRead() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenThrow(SQLException.class);
		bo.cancelOrder(ORDER_ID);
	}

	@Test(expected = BOException.class)
	public void testCancelOrder_ShouldThrowBOExceptionOnUpdate() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenReturn(order);
		when(dao.update(order)).thenThrow(SQLException.class);
		bo.cancelOrder(ORDER_ID);

	}

	@Test
	public void testDeleteOrder_Deletes_The_Order() throws BOException, SQLException {
		when(dao.delete(ORDER_ID)).thenReturn(1);
		boolean result = bo.deleteOrder(ORDER_ID);
		assertTrue(result);
		verify(dao).delete(ORDER_ID);
	}

	@Test
	public void testPlaceOrder_Should_Create_An_Order_1_positive_usingMatchers() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(any(Order.class))).thenReturn(new Integer(1));
		boolean result = bo.placeOrder(order);
		assertTrue(result);
		verify(dao).create(order);
	}

	@Test
	public void testPlaceOrder_Should_Create_An_Order_2_positive_usingMatchers() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(any(Order.class))).thenReturn(new Integer(1));
		boolean result = bo.placeOrder(order);
		assertTrue(result);
		verify(dao, times(1)).create(order);
		verify(dao, atLeast(1)).create(order);
	}

	@Test
	public void testPlaceOrder_Should_Not_Create_An_Order_negative_usingMatchers() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(any(Order.class))).thenReturn(new Integer(0));
		boolean result = bo.placeOrder(order);
		assertFalse(result);
		verify(dao).create(order);
	}

	@Test(expected = BOException.class)
	public void testPlaceOrder_Should_throwBOException_usingMatchers() throws SQLException, BOException {
		// Setting Expectations
		when(dao.create(any(Order.class))).thenThrow(SQLException.class);
		boolean result = bo.placeOrder(order);
	}

	@Test
	public void testCancelOrder_Should_Cancel_the_Order_positive_usingMatchers() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenReturn(order);
		when(dao.update(any(Order.class))).thenReturn(1);
		boolean result = bo.cancelOrder(ORDER_ID);
		assertTrue(result);
		verify(dao).read(ORDER_ID);
		verify(dao).update(order);
	}

	@Test
	public void testCancelOrder_Should_Not_Cancel_the_Order_negative_usingMatchers() throws SQLException, BOException {
		when(dao.read(ORDER_ID)).thenReturn(order);
		when(dao.update(any(Order.class))).thenReturn(0);
		boolean result = bo.cancelOrder(ORDER_ID);
		assertFalse(result);
		verify(dao).read(ORDER_ID);
		verify(dao).update(order);
	}
	
}

// Use  Matchers while Stubbing eg: when()