package com.bharath.junit.spring.service;

public interface TicketService {

	int buyTicket(String passengerName, String phone);
}
