package com.bharath.junit5;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;

@RunWith(JUnitPlatform.class)
public class GreetingImplTest {

	private Greeting greeting;

	@BeforeEach
	public void setup() {
		System.out.println("setup");
		greeting = new GreetingImpl();
	}

	@Test
	public void testGreetShouldReturnAValidOutput() {
		System.out.println("testGreetShouldReturnAValidOutput");
		String actual = greeting.greet1("JUnit");
		assertNotNull(actual);
		assertEquals("Hello JUnit", actual);
	}

// JUnit 4
//	@Test(expected = IllegalArgumentException.class)
//	public void testGreetShouldThrowAnException_For_NameIsNull() {
//		System.out.println("testGreetShouldThrowAnException_For_NameIsNull");
//		greeting.greet2(null);
//	}
//
//	@Test(expected = IllegalArgumentException.class)
//	public void testGreetShouldThrowAnException_For_NameIsBlankString() {
//		System.out.println("testGreetShouldThrowAnException_For_NameIsBlankStrings");
//		greeting.greet2("");
//	}

	// JUnit 5
	@Test
	public void testGreetShouldThrowAnException_For_NameIsNull() {
		System.out.println("testGreetShouldThrowAnException_For_NameIsNull");
		assertThrows(IllegalArgumentException.class, () -> {
			greeting.greet2(null);
		});
	}

	@Test
	public void testGreetShouldThrowAnException_For_NameIsBlankString() {
		System.out.println("testGreetShouldThrowAnException_For_NameIsBlankStrings");
		assertThrows(IllegalArgumentException.class, () -> {
			greeting.greet2("");
		});
	}

	@AfterEach
	public void teardown() {
		System.out.println("teardown");
		greeting = null;
	}

}
