package com.bharath.junit5;

public interface Greeting {
	String greet1(String name);
	String greet2(String name);
}
