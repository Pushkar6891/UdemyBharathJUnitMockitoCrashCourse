package com.bharath.junit5;

public class GreetingImpl implements Greeting {

	@Override
	public String greet1(String name) {
		return "Hello " + name;
	}

	@Override
	public String greet2(String name) {
		if (name == null || name.length() == 0) {
			throw new IllegalArgumentException();
		}
		return "Hello " + name;
	}

}
