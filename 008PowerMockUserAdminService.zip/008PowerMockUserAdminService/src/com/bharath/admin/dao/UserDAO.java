package com.bharath.admin.dao;

import com.bharath.admin.dto.User;
import com.bharath.admin.util.IDGenerator;

public class UserDAO {

	public int create(User user) {
		
		int generatedID = IDGenerator.generateID();
		// save user object to db
		return generatedID;
	}
}
