package com.bharath.admin.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bharath.admin.dto.User;
import com.bharath.admin.util.IDGenerator;

@RunWith(PowerMockRunner.class)
@PrepareForTest(IDGenerator.class)
public class UserDAOTest {

	@Test
	public void testCreateShouldReturnAUserID() {
		UserDAO userDAO = new UserDAO();
		
		mockStatic(IDGenerator.class);
		// Set Expectations
		when(IDGenerator.generateID()).thenReturn(1);
		User user = new User();
		int result = userDAO.create(user);
		assertEquals(1, result);
		verifyStatic();
	}

}
