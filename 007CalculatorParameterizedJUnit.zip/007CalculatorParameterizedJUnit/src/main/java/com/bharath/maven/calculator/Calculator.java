package com.bharath.maven.calculator;

public interface Calculator {
	int add(int n1, int n2);
}
