package com.bharath.maven.calculator;

public class CalculatorImpl implements Calculator {

	@Override
	public int add(int n1, int n2) {
		return n1+n2;
	}

}
