package com.bharath.maven.calculator;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class CalculatorImplTest {

	// Step 1: create fields
	private int n1;
	private int n2;
	private int expectedResult;

	// Step 2: create constructor
	public CalculatorImplTest(int n1, int n2, int expectedResult) {
		this.n1 = n1;
		this.n2 = n2;
		this.expectedResult = expectedResult;
	}

	// Step 3: create a static data set
	@Parameters
	public static Collection<Integer[]> data() {
		return Arrays.asList(new Integer[][] { { -1, 2, 1 }, { 1, 2, 3 }, { 6, 7, 13 } });
	}

	@Test
	public void testAddShouldReturnAResult() {
		CalculatorImpl calculator = new CalculatorImpl();
		int result = calculator.add(10, 20);
		assertEquals(30, result);
	}

	@Test
	public void testAddShouldReturnAResultParameterized() {
		CalculatorImpl calculator = new CalculatorImpl();
		int result = calculator.add(n1, n2);
		assertEquals(expectedResult, result);
	}

}
