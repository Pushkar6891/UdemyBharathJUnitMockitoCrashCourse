package com.bharath.trainings.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GreetingImplTest {

	private Greeting greeting;

	@Before
	public void setup() {
		System.out.println("setup");
		greeting = new GreetingImpl();
	}

	@Test
	public void testGreetShouldReturnAValidOutput() {
		System.out.println("testGreetShouldReturnAValidOutput");
		String actual = greeting.greet1("JUnit");
		assertNotNull(actual);
		assertEquals("Hello JUnit", actual);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGreetShouldThrowAnException_For_NameIsNull() {
		System.out.println("testGreetShouldThrowAnException_For_NameIsNull");
		greeting.greet2(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGreetShouldThrowAnException_For_NameIsBlankString() {
		System.out.println("testGreetShouldThrowAnException_For_NameIsBlankStrings");
		greeting.greet2("");
	}

	@After
	public void teardown() {
		System.out.println("teardown");
		greeting = null;
	}

}
