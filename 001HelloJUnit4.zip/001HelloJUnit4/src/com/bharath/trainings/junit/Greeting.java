package com.bharath.trainings.junit;

public interface Greeting {
	String greet1(String name);
	String greet2(String name);
}
