package com.bharath.mockito.scrapbook;

public class B {

	public void voidMethod() throws Exception {

	}
}
