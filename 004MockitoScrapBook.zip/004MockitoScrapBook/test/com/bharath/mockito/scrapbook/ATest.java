package com.bharath.mockito.scrapbook;

import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class ATest {

	@Mock
	B b;
	private A a;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		a = new A(b);
	}

	@Test
	public void testUsesSomeVoidMethod_ShouldCallTheVoidMethod_1_StubVoidMethodsImplicitly() throws Exception {
		a.usesVoidMethod();
		verify(b).voidMethod();
	}

	@Test
	public void testUsesSomeVoidMethod_ShouldCallTheVoidMethod_2_StubVoidMethodsImplicitly() throws Exception {
		assertEquals(1, a.usesVoidMethod());
		verify(b).voidMethod();
	}

	@Test
	public void testUsesSomeVoidMethod_ShouldCallTheVoidMethod_3_StubVoidMethodsImplicitly() throws Exception {
		assertSame(1, a.usesVoidMethod());
		verify(b).voidMethod();
	}
	
	@Test
	public void testUsesSomeVoidMethod_ShouldCallTheVoidMethod_1_StubVoidMethodsExplicitly() throws Exception {
		doNothing().when(b).voidMethod();
		a.usesVoidMethod();
		verify(b).voidMethod();
	}
	
//	@Test(expected = RuntimeException.class)
//	public void usesVoidMethodShouldThrowRuntimeException() throws Exception {
//		doThrow(Exception.class).when(b).voidMethod();
//		a.usesVoidMethod();
//	}

//	@Test(expected = RuntimeException.class)
//	public void testConsecutiveCalls() throws Exception {
//		doNothing().doThrow(Exception.class).when(b).voidMethod();
//		a.usesVoidMethod();
//		verify(b).voidMethod();
//		a.usesVoidMethod();
//
//	}

}
